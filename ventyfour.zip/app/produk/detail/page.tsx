import { notFound } from "next/navigation";
import { products } from "@/data/products";
import Image from "next/image";
import Link from "next/link";

export async function generateMetadata() {
  const product = products.find((p) => p.slug === "product-1");
  if (!product) return {};
  return {
    title: `${product.name} | Ventyfour`,
    description: product.description,
  };
}

export default function ProductDetailPage() {
  const product = products.find((p) => p.slug === "product-1");

  if (!product) return notFound();

  return (
    <section className="py-20 px-4 max-w-4xl mx-auto">
      {/* Breadcrumb */}
      <div className="text-sm text-neutral-500 mb-4">
        <Link href="/" className="hover:underline">
          Beranda
        </Link>{" "}
        /{" "}
        <Link href="/produk" className="hover:underline">
          Produk
        </Link>{" "}
        / {product.name}
      </div>

      {/* Judul & Gambar */}
      <div className="mb-10">
        <h1 className="text-3xl font-bold text-blue-600 mb-4">
          {product.name}
        </h1>
        <Image
          src={product.image}
          alt={product.name}
          width={800}
          height={400}
          className="rounded-xl"
        />
      </div>

      {/* Deskripsi */}
      <p className="text-gray-700 dark:text-gray-300 mb-6">
        {product.description}
      </p>

      {/* Harga */}
      <div className="text-xl font-semibold text-blue-700 mb-4">
        Harga mulai {product.pricing?.basic}
      </div>

      {/* CTA */}
      <Link
        href="/pesan"
        className="inline-block bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 transition"
      >
        Pesan Sekarang
      </Link>
    </section>
  );
}
